(() => {
    "use strict";

    const STORAGE_KEY = "aajonusThemeV1";

    const THEMES = [
        {
            id: "archive",
            label: "Archive"
        },
        {
            id: "living-sun",
            label: "Living Sun"
        }
    ];

    function isValidTheme(value) {
        return THEMES.some(
            theme => theme.id === value
        );
    }

    function readStoredTheme() {
        try {
            const value = localStorage.getItem(
                STORAGE_KEY
            );

            return isValidTheme(value)
                ? value
                : "archive";
        } catch {
            return "archive";
        }
    }

    function updateSwitcher(themeId) {
        document
            .querySelectorAll(
                ".theme-switcher-button"
            )
            .forEach(button => {
                const active =
                    button.dataset.theme ===
                    themeId;

                button.classList.toggle(
                    "active",
                    active
                );

                button.setAttribute(
                    "aria-pressed",
                    active ? "true" : "false"
                );
            });
    }

    function applyTheme(themeId) {
        const theme = isValidTheme(themeId)
            ? themeId
            : "archive";

        document.documentElement.setAttribute(
            "data-theme",
            theme
        );

        try {
            localStorage.setItem(
                STORAGE_KEY,
                theme
            );
        } catch {
            // The selected theme still applies to this page.
        }

        updateSwitcher(theme);
    }

    function addPageIdentity() {
        const isHome = Boolean(
            document.querySelector(".intro")
        );

        const isArticle = Boolean(
            document.querySelector(
                ".article-header"
            )
        );

        document.body.classList.toggle(
            "home-view",
            isHome
        );

        document.body.classList.toggle(
            "article-view",
            isArticle
        );
    }

    function addLivingSunHeroDetails() {
        const intro = document.querySelector(
            ".intro"
        );

        if (
            !intro ||
            intro.querySelector(
                ".living-sun-emblem"
            )
        ) {
            return;
        }

        const emblem = document.createElement(
            "div"
        );

        emblem.className =
            "living-sun-emblem";

        emblem.setAttribute(
            "aria-hidden",
            "true"
        );

        emblem.innerHTML = `
            <span class="living-sun-emblem-rays"></span>
            <span class="living-sun-emblem-core">AV</span>
        `;

        const fieldNote =
            document.createElement("p");

        fieldNote.className =
            "living-sun-field-note";

        fieldNote.innerHTML = `
            <span>Field archive</span>
            <strong>Recorded voices, living memory</strong>
        `;

        intro.append(
            emblem,
            fieldNote
        );
    }

    function buildSwitcher() {
        if (
            document.getElementById(
                "themeSwitcher"
            )
        ) {
            updateSwitcher(
                readStoredTheme()
            );

            return;
        }

        const switcher =
            document.createElement("div");

        switcher.id = "themeSwitcher";
        switcher.className =
            "theme-switcher";

        switcher.setAttribute(
            "role",
            "group"
        );

        switcher.setAttribute(
            "aria-label",
            "Archive appearance"
        );

        const label =
            document.createElement("span");

        label.className =
            "theme-switcher-label";

        label.textContent = "View";

        switcher.appendChild(label);

        THEMES.forEach(theme => {
            const button =
                document.createElement("button");

            button.type = "button";
            button.className =
                "theme-switcher-button";

            button.dataset.theme = theme.id;
            button.textContent = theme.label;

            button.addEventListener(
                "click",
                () => {
                    applyTheme(theme.id);
                }
            );

            switcher.appendChild(button);
        });

        const headerInner =
            document.querySelector(
                ".header-inner"
            );

        const navigation =
            document.querySelector(
                ".top-nav"
            );

        const backLink =
            document.getElementById(
                "backLink"
            );

        if (navigation) {
            navigation.appendChild(
                switcher
            );
        } else if (
            headerInner &&
            backLink
        ) {
            headerInner.insertBefore(
                switcher,
                backLink
            );
        } else if (headerInner) {
            headerInner.appendChild(
                switcher
            );
        } else {
            document.body.appendChild(
                switcher
            );
        }

        updateSwitcher(
            readStoredTheme()
        );
    }

    applyTheme(readStoredTheme());

    function initialize() {
        addPageIdentity();
        addLivingSunHeroDetails();
        buildSwitcher();
    }

    if (
        document.readyState === "loading"
    ) {
        document.addEventListener(
            "DOMContentLoaded",
            initialize,
            { once: true }
        );
    } else {
        initialize();
    }

    window.addEventListener(
        "storage",
        event => {
            if (
                event.key === STORAGE_KEY &&
                isValidTheme(event.newValue)
            ) {
                applyTheme(event.newValue);
            }
        }
    );
})();
