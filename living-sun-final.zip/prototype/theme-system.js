(() => {
    "use strict";

    const STORAGE_KEY = "aajonusThemeV1";

    const THEMES = [
        {
            id: "archive",
            label: "Archive"
        },
        {
            id: "living-sun",
            label: "Living Sun"
        }
    ];

    function isValidTheme(value) {
        return THEMES.some(
            theme => theme.id === value
        );
    }

    function readStoredTheme() {
        try {
            const value = localStorage.getItem(
                STORAGE_KEY
            );

            return isValidTheme(value)
                ? value
                : "archive";
        } catch {
            return "archive";
        }
    }

    function updateSwitcher(themeId) {
        document
            .querySelectorAll(
                ".theme-switcher-button"
            )
            .forEach(button => {
                const active =
                    button.dataset.theme ===
                    themeId;

                button.classList.toggle(
                    "active",
                    active
                );

                button.setAttribute(
                    "aria-pressed",
                    active ? "true" : "false"
                );
            });
    }

    function applyTheme(themeId) {
        const theme = isValidTheme(themeId)
            ? themeId
            : "archive";

        document.documentElement.setAttribute(
            "data-theme",
            theme
        );

        try {
            localStorage.setItem(
                STORAGE_KEY,
                theme
            );
        } catch {
            // The theme still works for the current page.
        }

        updateSwitcher(theme);
    }

    function addPageIdentity() {
        document.body.classList.toggle(
            "home-view",
            Boolean(
                document.querySelector(
                    ".intro"
                )
            )
        );

        document.body.classList.toggle(
            "article-view",
            Boolean(
                document.querySelector(
                    ".article-header"
                )
            )
        );
    }

    function decorateHeroCopy(intro) {
        const copyPanel = intro.firstElementChild;

        if (!copyPanel) {
            return;
        }

        copyPanel.classList.add(
            "intro-copy-panel"
        );

        const existingKicker =
            copyPanel.querySelector(
                ".kicker"
            );

        if (
            existingKicker &&
            !copyPanel.querySelector(
                ".living-sun-kicker"
            )
        ) {
            const kicker =
                document.createElement("p");

            kicker.className =
                "living-sun-kicker";

            kicker.textContent =
                "Living field archive";

            existingKicker.insertAdjacentElement(
                "afterend",
                kicker
            );
        }

        const title = copyPanel.querySelector("h1");

        if (
            title &&
            !title.querySelector(
                ".living-sun-title"
            )
        ) {
            title.innerHTML = `
                <span class="archive-title">
                    Research the record.
                </span>

                <span class="living-sun-title">
                    The living record.
                </span>
            `;
        }

        const description =
            copyPanel.querySelector(
                ".intro-copy"
            );

        if (
            description &&
            !description.querySelector(
                ".living-sun-intro-copy"
            )
        ) {
            description.innerHTML = `
                <span class="archive-intro-copy">
                    A structured library of transcripts, workshops,
                    interviews, books, newsletters, videos, and surviving
                    source documents.
                </span>

                <span class="living-sun-intro-copy">
                    Voices, books, recordings, and surviving source material,
                    preserved inside a sunlit research garden.
                </span>
            `;
        }
    }

    function createPhoto(
        className,
        source,
        alt = ""
    ) {
        const figure =
            document.createElement("figure");

        figure.className =
            `living-photo ${className}`;

        figure.setAttribute(
            "aria-hidden",
            "true"
        );

        const image =
            document.createElement("img");

        image.src = source;
        image.alt = alt;

        figure.appendChild(image);

        return figure;
    }

    function addLivingScene(intro) {
        if (
            intro.querySelector(
                ".living-scene"
            )
        ) {
            return;
        }

        const scene =
            document.createElement("div");

        scene.className = "living-scene";
        scene.setAttribute(
            "aria-hidden",
            "true"
        );

        const redGarden = createPhoto(
            "living-photo-red",
            "/prototype/assets/vibe-red-garden.webp"
        );

        const greenHills = createPhoto(
            "living-photo-hills",
            "/prototype/assets/vibe-green-hills.webp"
        );

        const memory = createPhoto(
            "living-photo-memory",
            "/prototype/assets/vibe-portrait.webp"
        );

        const memoryCaption =
            document.createElement("span");

        memoryCaption.textContent =
            "Field record · living memory";

        memory.appendChild(
            memoryCaption
        );

        const propSources = [
            [
                "living-prop-milk",
                "/prototype/assets/scene-milk.svg"
            ],
            [
                "living-prop-recorder",
                "/prototype/assets/scene-recorder.svg"
            ],
            [
                "living-prop-flowers",
                "/prototype/assets/scene-flowers.svg"
            ],
            [
                "living-prop-books",
                "/prototype/assets/scene-books.svg"
            ]
        ];

        const props = propSources.map(
            ([className, source]) => {
                const image =
                    document.createElement("img");

                image.className = className;
                image.src = source;
                image.alt = "";

                return image;
            }
        );

        const bubbles = [
            "living-bubble-one",
            "living-bubble-two",
            "living-bubble-three"
        ].map(className => {
            const bubble =
                document.createElement("span");

            bubble.className =
                `living-bubble ${className}`;

            return bubble;
        });

        scene.append(
            redGarden,
            greenHills,
            memory,
            ...props,
            ...bubbles
        );

        intro.prepend(scene);

        const seal =
            document.createElement("div");

        seal.className =
            "living-hero-seal";

        seal.setAttribute(
            "aria-hidden",
            "true"
        );

        seal.textContent = "AV";

        intro.appendChild(seal);
    }

    function collectionGlyph(format) {
        const glyphs = {
            "Q&A": "?",
            Interview: "◉",
            Book: "▤",
            Newsletter: "✉"
        };

        return glyphs[format] || "✦";
    }

    function decorateCollections() {
        document
            .querySelectorAll(
                ".collection"
            )
            .forEach(card => {
                if (
                    card.querySelector(
                        ".collection-icon"
                    )
                ) {
                    return;
                }

                const icon =
                    document.createElement("span");

                icon.className =
                    "collection-icon";

                icon.setAttribute(
                    "aria-hidden",
                    "true"
                );

                icon.textContent =
                    collectionGlyph(
                        card.dataset.format
                    );

                const arrow =
                    document.createElement("span");

                arrow.className =
                    "collection-arrow";

                arrow.setAttribute(
                    "aria-hidden",
                    "true"
                );

                arrow.textContent = "→";

                card.prepend(icon);
                card.appendChild(arrow);
            });
    }

    function decorateFeaturedRecord() {
        const featured =
            document.querySelector(
                ".featured-record"
            );

        if (
            !featured ||
            featured.querySelector(
                ".featured-photo"
            )
        ) {
            return;
        }

        const figure =
            document.createElement("figure");

        figure.className =
            "featured-photo";

        figure.setAttribute(
            "aria-hidden",
            "true"
        );

        const image =
            document.createElement("img");

        image.src =
            "/prototype/assets/vibe-portrait.webp";

        image.alt = "";

        figure.appendChild(image);
        featured.appendChild(figure);
    }

    function decorateHome() {
        const intro =
            document.querySelector(
                ".intro"
            );

        if (!intro) {
            return;
        }

        decorateHeroCopy(intro);
        addLivingScene(intro);
        decorateCollections();
        decorateFeaturedRecord();
    }

    function decorateArticle() {
        const header =
            document.querySelector(
                ".article-header"
            );

        if (
            !header ||
            header.querySelector(
                ".article-scene"
            )
        ) {
            return;
        }

        const scene =
            document.createElement("div");

        scene.className =
            "article-scene";

        scene.setAttribute(
            "aria-hidden",
            "true"
        );

        const photo =
            document.createElement("figure");

        photo.className =
            "article-photo";

        const portrait =
            document.createElement("img");

        portrait.src =
            "/prototype/assets/vibe-portrait.webp";

        portrait.alt = "";

        photo.appendChild(portrait);

        const milk =
            document.createElement("img");

        milk.className =
            "article-milk";

        milk.src =
            "/prototype/assets/scene-milk.svg";

        milk.alt = "";

        const flowers =
            document.createElement("img");

        flowers.className =
            "article-flowers";

        flowers.src =
            "/prototype/assets/scene-flowers.svg";

        flowers.alt = "";

        scene.append(
            photo,
            milk,
            flowers
        );

        header.prepend(scene);
    }

    function addSceneMotion() {
        const intro =
            document.querySelector(
                ".intro"
            );

        if (
            !intro ||
            window.matchMedia(
                "(prefers-reduced-motion: reduce)"
            ).matches
        ) {
            return;
        }

        intro.addEventListener(
            "pointermove",
            event => {
                const bounds =
                    intro.getBoundingClientRect();

                const x =
                    (
                        event.clientX -
                        bounds.left
                    ) /
                    bounds.width -
                    0.5;

                const y =
                    (
                        event.clientY -
                        bounds.top
                    ) /
                    bounds.height -
                    0.5;

                intro.style.setProperty(
                    "--scene-x",
                    `${x * 14}px`
                );

                intro.style.setProperty(
                    "--scene-y",
                    `${y * 10}px`
                );
            }
        );

        intro.addEventListener(
            "pointerleave",
            () => {
                intro.style.setProperty(
                    "--scene-x",
                    "0px"
                );

                intro.style.setProperty(
                    "--scene-y",
                    "0px"
                );
            }
        );
    }

    function buildSwitcher() {
        if (
            document.getElementById(
                "themeSwitcher"
            )
        ) {
            updateSwitcher(
                readStoredTheme()
            );

            return;
        }

        const switcher =
            document.createElement("div");

        switcher.id = "themeSwitcher";
        switcher.className =
            "theme-switcher";

        switcher.setAttribute(
            "role",
            "group"
        );

        switcher.setAttribute(
            "aria-label",
            "Archive appearance"
        );

        const label =
            document.createElement("span");

        label.className =
            "theme-switcher-label";

        label.textContent = "Mode";

        switcher.appendChild(label);

        THEMES.forEach(theme => {
            const button =
                document.createElement("button");

            button.type = "button";
            button.className =
                "theme-switcher-button";

            button.dataset.theme = theme.id;
            button.textContent = theme.label;

            button.addEventListener(
                "click",
                () => {
                    applyTheme(theme.id);
                }
            );

            switcher.appendChild(button);
        });

        const navigation =
            document.querySelector(
                ".top-nav"
            );

        const headerInner =
            document.querySelector(
                ".header-inner"
            );

        const backLink =
            document.getElementById(
                "backLink"
            );

        if (navigation) {
            navigation.appendChild(switcher);
        } else if (
            headerInner &&
            backLink
        ) {
            headerInner.insertBefore(
                switcher,
                backLink
            );
        } else if (headerInner) {
            headerInner.appendChild(
                switcher
            );
        } else {
            document.body.appendChild(
                switcher
            );
        }

        updateSwitcher(
            readStoredTheme()
        );
    }

    applyTheme(readStoredTheme());

    function initialize() {
        addPageIdentity();
        decorateHome();
        decorateArticle();
        buildSwitcher();
        addSceneMotion();
    }

    if (
        document.readyState === "loading"
    ) {
        document.addEventListener(
            "DOMContentLoaded",
            initialize,
            { once: true }
        );
    } else {
        initialize();
    }

    window.addEventListener(
        "storage",
        event => {
            if (
                event.key === STORAGE_KEY &&
                isValidTheme(event.newValue)
            ) {
                applyTheme(event.newValue);
            }
        }
    );
})();
