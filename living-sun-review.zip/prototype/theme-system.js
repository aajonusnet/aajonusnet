(() => {
    "use strict";

    const STORAGE_KEY =
        "aajonusThemeV1";

    const THEMES = [
        {
            id: "archive",
            label: "Archive"
        },
        {
            id: "living-sun",
            label: "Living Sun"
        }
    ];

    function validTheme(value) {
        return THEMES.some(
            theme =>
                theme.id === value
        );
    }

    function storedTheme() {
        try {
            const value =
                localStorage.getItem(
                    STORAGE_KEY
                );

            return validTheme(value)
                ? value
                : "archive";
        } catch {
            return "archive";
        }
    }

    function applyTheme(themeId) {
        const theme =
            validTheme(themeId)
                ? themeId
                : "archive";

        document
            .documentElement
            .setAttribute(
                "data-theme",
                theme
            );

        try {
            localStorage.setItem(
                STORAGE_KEY,
                theme
            );
        } catch {
            /*
             * Theme still works for the
             * current page when storage
             * is unavailable.
             */
        }

        document
            .querySelectorAll(
                ".theme-switcher-button"
            )
            .forEach(button => {
                const active =
                    button.dataset.theme ===
                    theme;

                button.classList.toggle(
                    "active",
                    active
                );

                button.setAttribute(
                    "aria-pressed",
                    active
                        ? "true"
                        : "false"
                );
            });
    }

    /*
     * Apply the stored theme before
     * the page body finishes loading.
     */

    applyTheme(
        storedTheme()
    );

    function buildSwitcher() {
        if (
            document.getElementById(
                "themeSwitcher"
            )
        ) {
            return;
        }

        const switcher =
            document.createElement(
                "div"
            );

        switcher.id =
            "themeSwitcher";

        switcher.className =
            "theme-switcher";

        switcher.setAttribute(
            "role",
            "group"
        );

        switcher.setAttribute(
            "aria-label",
            "Archive appearance"
        );

        const label =
            document.createElement(
                "span"
            );

        label.className =
            "theme-switcher-label";

        label.textContent =
            "Appearance";

        switcher.appendChild(
            label
        );

        THEMES.forEach(theme => {
            const button =
                document.createElement(
                    "button"
                );

            button.type =
                "button";

            button.className =
                "theme-switcher-button";

            button.dataset.theme =
                theme.id;

            button.textContent =
                theme.label;

            button.addEventListener(
                "click",
                () => {
                    applyTheme(
                        theme.id
                    );
                }
            );

            switcher.appendChild(
                button
            );
        });

        document.body.appendChild(
            switcher
        );

        applyTheme(
            storedTheme()
        );
    }

    if (
        document.readyState ===
        "loading"
    ) {
        document.addEventListener(
            "DOMContentLoaded",
            buildSwitcher,
            {
                once: true
            }
        );
    } else {
        buildSwitcher();
    }

    window.addEventListener(
        "storage",
        event => {
            if (
                event.key ===
                    STORAGE_KEY &&
                validTheme(
                    event.newValue
                )
            ) {
                applyTheme(
                    event.newValue
                );
            }
        }
    );
})();
